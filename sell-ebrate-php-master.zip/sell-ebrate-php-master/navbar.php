<!-- ako lang ni himuon para dili ta mag balik balik ug edit sa each navs -->
<!-- ok-->

<html>

<body>

  <nav class="navbar-stylish">
    <img src="/assets/images/logo.svg" class="logo">
    <h1>
      Sell Ebrate
    </h1>
      <ul>
      <li><h1><a href="index.php">Index</a></h1></li>
      <li><h1><a href="register.php">Register</a></h1></li>
      <li><h1><a href="login.php">Login</a></h1></li>
      <li><h1><a href="aboutUs.php">About Us</a></h1></li>
      <li><h1><a href="contactUs.php">Contact Us</a></h1></li>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
        crossorigin="anonymous"></script>
      </ul>
    
  </nav>
</body>

</html>
